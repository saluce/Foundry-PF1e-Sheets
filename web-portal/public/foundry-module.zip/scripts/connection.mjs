export const sourceStateKey=world=>world+':portal';
export function inventoryConnection(read){
 const url=String(read('portalEndpoint')||'').trim(),token=read('portalToken');let u;
 try{u=new URL(url);}catch{throw Error('Enter the website /api/bridge URL in module settings.');}
 if(u.pathname!=='/api/bridge'||u.search||u.hash||u.username||u.password||!(u.protocol==='https:'||u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname)))throw Error('Use an HTTPS website /api/bridge URL, or HTTP on localhost for testing.');
 if(!token)throw Error('Enter the website connection secret in module settings first.');
 return {portal:true,url,token};
}
