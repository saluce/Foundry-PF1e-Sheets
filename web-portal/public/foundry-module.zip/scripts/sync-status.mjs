import {normalize} from './core.mjs';
const canonical=rows=>JSON.stringify(rows.map(normalize).sort((a,b)=>a.id.localeCompare(b.id)));
export function syncStatus({connected=true,configured=true,binding='',remoteBinding='',mapped=0,baseline=[],local=[],remote=[]}={}){
 if(!configured)return {level:'red',label:'Not configured',detail:'Enter the website URL and GM connection secret in module settings.'};
 if(!connected)return {level:'red',label:'Disconnected',detail:'The website could not be reached. Check the server, URL and connection secret.'};
 if(!mapped)return {level:'yellow',label:'Connected · map characters',detail:'Choose owners and actors, then preview sync.'};
 if(binding&&binding!==remoteBinding)return {level:'red',label:'Different ledger',detail:'The website ledger differs from the saved pairing. Check the connection before syncing.'};
 if(!binding)return {level:'yellow',label:'Connected · first sync needed',detail:'Preview and apply the first inventory sync.'};
 if(canonical(local)!==canonical(baseline)||canonical(remote)!==canonical(baseline))return {level:'yellow',label:'Connected · out of sync',detail:'Inventory changes need review. Open Preview sync.'};
 return {level:'green',label:'Connected · in sync',detail:'Mapped inventories match the last confirmed sync.'};
}
