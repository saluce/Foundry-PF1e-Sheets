# Wayfinder’s Rest · PF1 Sync

Use the party website for inventories, character sheets, preparation and shopping. The Foundry module connects to that website for reviewed inventory sync, current HP and campaign tracking.

## Connect Foundry

1. Install and enable the module in a Pathfinder 1 world.
2. In the website GM desk, open Foundry connection. Add the Foundry browser address, including its port. A trailing slash is accepted. Generate a GM connection secret if one is not already configured.
3. Enter the website /api/bridge URL and that secret in the module’s Website connection settings. Keep the secret in the GM browser.
4. Open Inventory · Website Sync in Foundry’s Actors sidebar. Map inventory owners to actors, then Preview sync and apply the reviewed changes.
5. Review the website HP feed before enabling it. Maximum HP remains calculated by Foundry.

## Connection lights

The GM Actors sidebar and sync panel show a light with text. Green means the website is reachable and mapped inventories match the last confirmed sync. Yellow means the connection works but mapping, first sync or changed inventories need review. Red means configuration, connectivity or ledger pairing needs attention. Status checks are read-only and run every 15 seconds while the GM browser is open.

## Imports and backups

Import existing inventory data through the website GM desk. Spreadsheet exports can still be used with the website import tools. Character files are uploaded from the character page. Preview imports before confirming them.

Back up the website database and application files. The module also downloads an actor recovery file before applying inventory sync. Removing a website row never automatically deletes an in-game item. Review conflicts before applying.

Private GM item details stay on the website. Reveals copy only selected fields to the player inventory. Use the website’s item lookup and storage tools for preparation.

## Verification

Run node --test tests/*.test.mjs in the module folder and in web-portal. Live Foundry visual checks and sync with a running world must still be checked in Foundry.
